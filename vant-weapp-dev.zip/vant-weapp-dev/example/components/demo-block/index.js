Component({
  properties: {
    title: String,
    padding: Boolean
  },

  externalClasses: ['custom-class']
});
